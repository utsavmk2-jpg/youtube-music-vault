@echo off
title YouTube Music Vault
echo ====================================================
echo           YouTube Music Vault Web Server
echo ====================================================
echo Local PC Access:    http://127.0.0.1:5000
echo Network Access:     Listening on all interfaces (0.0.0.0:5000)
echo Press Ctrl+C to stop the server.
echo.
python app.py
pause
