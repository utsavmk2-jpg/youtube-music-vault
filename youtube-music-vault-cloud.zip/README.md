# 🎵 YouTube Music Vault

A modern YouTube to downloadable music website. Paste any YouTube video link, convert it to high-quality audio (`.mp3`), save it to your permanent personal library on the website, listen anytime with a full-featured music player, and download songs directly to your device.

---

## ✨ Features

- **YouTube Link Converter**:
  - Supports standard YouTube links (`watch?v=...`), short links (`youtu.be/...`), YouTube Shorts, and YouTube Music links.
  - Automatically fetches video title, channel/artist name, duration, and high-definition thumbnail.
  - Converts audio into crisp MP3 (`192 kbps`) format using high-performance `yt-dlp` and `ffmpeg`.

- **Permanent Website Library**:
  - Automatically saves converted songs to an SQLite database.
  - Songs remain in your library across server restarts and device reboots.
  - Switch between visual **Grid Cards** and compact **List View**.
  - Real-time search and filter across all saved tracks.
  - One-click deletion and file management.

- **Full-Featured Audio Player (YouTube Music / Spotify Style)**:
  - Bottom floating persistent player.
  - Animated audio visualizer bars when music is playing.
  - Controls: Play/Pause, Next Track, Previous Track, Fast-forward (+10s), Rewind (-10s).
  - Loop Modes (Off, Repeat All, Repeat Current Song) & Shuffle playback.
  - Interactive smooth seekbar with time elapsed / duration.
  - Volume slider and one-click Mute toggle.

- **YouTube Cinema Mode (Video Player)**:
  - Watch the video directly on the website just like on YouTube with the built-in cinema viewer!

- **Offline File Downloads**:
  - Direct "Download MP3" button on every song card and inside the bottom player.
  - Downloads the converted `.mp3` file directly to your PC, phone, or tablet.

- **Quick-Try Presets**:
  - Sample royalty-free and popular tracks ready to test immediately with a single click.

---

## 🚀 How to Run

1. Open PowerShell or Command Prompt in this folder:
   ```bash
   cd "C:\Users\Utsav\.gemini\antigravity\scratch\youtube-music-vault"
   ```

2. Run the server:
   ```bash
   python app.py
   ```
   *(Or simply double-click `run.bat`)*

3. Open your web browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

---

## 🛠️ Tech Stack

- **Backend**: Python 3, Flask, SQLite3, `yt-dlp`, `imageio-ffmpeg`
- **Frontend**: Vanilla HTML5, CSS3 (Modern YouTube Dark Theme), Vanilla JavaScript (No heavy frameworks required)
- **Audio/Video**: HTML5 Audio API, YouTube Iframe API
