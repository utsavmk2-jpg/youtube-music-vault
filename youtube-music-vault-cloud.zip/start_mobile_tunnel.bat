@echo off
title Mobile Public Tunnel - YouTube Music Vault
echo ====================================================
echo       YouTube Music Vault - Public Mobile Link
echo ====================================================
echo.
echo Connecting to public tunnel...
echo Your phone can open this link from ANY network (even 4G/5G).
echo.
ssh -o StrictHostKeyChecking=no -R 80:127.0.0.1:5000 nokey@localhost.run
pause
