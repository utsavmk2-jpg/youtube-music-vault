@echo off
title Pinggy Mobile Tunnel - YouTube Music Vault
echo ====================================================
echo       YouTube Music Vault - Public Mobile Link
echo ====================================================
echo.
echo Connecting to Pinggy tunnel...
echo Your phone can open this link from ANY network (even 4G/5G).
echo.
ssh -o StrictHostKeyChecking=no -p 443 -R0:127.0.0.1:5000 a.pinggy.io
pause
